INSERT INTO practice_db.skills (id, cms, bar) VALUES (1, 'wordpress', 20);
INSERT INTO practice_db.skills (id, cms, bar) VALUES (2, 'opencart', 30);
INSERT INTO practice_db.skills (id, cms, bar) VALUES (3, 'modx', 40);
INSERT INTO practice_db.skills (id, cms, bar) VALUES (4, 'simplacms', 50);
INSERT INTO practice_db.skills (id, cms, bar) VALUES (5, 'joomla', 70);
INSERT INTO practice_db.skills (id, cms, bar) VALUES (6, 'blablalba', 100);