INSERT INTO practice_db.project (id, studio, description) VALUES (1, 'velocity', 'lore lorem lorem');
INSERT INTO practice_db.project (id, studio, description) VALUES (2, 'devstudio', 'lore lorem lorem');
INSERT INTO practice_db.project (id, studio, description) VALUES (3, 'tempo', 'lorem345');
INSERT INTO practice_db.project (id, studio, description) VALUES (4, 'atom', 'lorem3345');
INSERT INTO practice_db.project (id, studio, description) VALUES (5, 'delta', 'lorem3вававававав345');