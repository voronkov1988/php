



<?php
if ($_POST['name2'] and $_POST['familia2'] and $_POST['age']){
    echo "привет! меня зовут -" . " " . $_POST["name2"] . " " . $_POST['familia2'] . " " . "мой возраст" . " " . $_POST['age2'] . "лет";
}
else{
    echo ' вавыавыолаваыл';
}