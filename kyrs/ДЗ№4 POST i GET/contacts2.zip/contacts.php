



<?php
if ($_GET['name'] and $_GET['familia'] and $_GET['age']){
    echo "привет! меня зовут -" . " " . $_GET["name"] . " " . $_GET['familia'] . " " . "мой возраст" . " " . $_GET['age'] . "лет";
}
else{
    echo ' вавыавыолаваыл';
}