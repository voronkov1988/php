create table images
(
  id        int auto_increment
    primary key,
  imagename varchar(50) not null,
  extension varchar(30) not null
);

