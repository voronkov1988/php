INSERT INTO practice_db.interest (id, interes) VALUES (1, 'рыбалка');
INSERT INTO practice_db.interest (id, interes) VALUES (2, 'Пиво');
INSERT INTO practice_db.interest (id, interes) VALUES (3, 'Спорт');