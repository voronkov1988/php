INSERT INTO practice_db.language (id, lang) VALUES (1, 'English');
INSERT INTO practice_db.language (id, lang) VALUES (2, 'Belarus');
INSERT INTO practice_db.language (id, lang) VALUES (3, 'Russian');