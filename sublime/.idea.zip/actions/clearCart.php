<?php

require_once '../db.php';
unset($_SESSION['totalGood']);
unset($_SESSION['totalPrice']);
unset($_SESSION['cart']);